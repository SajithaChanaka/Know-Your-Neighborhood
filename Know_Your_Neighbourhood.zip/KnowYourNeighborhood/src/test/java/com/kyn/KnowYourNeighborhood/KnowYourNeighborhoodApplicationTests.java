package com.kyn.KnowYourNeighborhood;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KnowYourNeighborhoodApplicationTests {

	@Test
	void contextLoads() {
	}

}
